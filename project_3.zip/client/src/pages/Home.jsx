import HomeCarousel from "../components/HomeCarousel/HomeCarousel";

const Home = () => {
  return (
    <div>
      <HomeCarousel />
    </div>
  );
};

export default Home;
