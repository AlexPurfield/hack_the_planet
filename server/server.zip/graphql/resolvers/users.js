require("dotenv").config();
const User = require("../models/User");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

module.exports = {
  Mutation: {
    async registerUser(_, { registerInput: { name, email, password } }) {
      // See if an old user exists with email attempting to register
      const oldUser = await User.findOne({ email });

      // Throw Error if user exists
      if (oldUser) {
        throw new Error("User already exists. Please login.");
      }

      // Encrypt Password
      var encryptedPassword = await bcrypt.hash(password, 10);

      // Build out mongoose model
      const newUser = new User({
        name: name,
        email: email.toLowerCase(),
        password: encryptedPassword,
      });

      // Create our JWT
      const token = jwt.sign(
        { user_id: newUser._id, email },
        process.env.VITE_JWT_TOKEN_KEY,
        {
          expiresIn: "2h",
        }
      );

      newUser.token = token;
      // Save our user in MongoDB
      const res = await newUser.save();

      return {
        id: res._id,
        ...res._doc,
      };
    },
    async loginUser(_, { LoginInput: { email, password } }) {
      // See if user exists
      const user = await User.findOne({ email });

      // Check if entered password = hashed password in DB
      if (user && (await bcrypt.compare(password, user.password))) {
        // Create a New JWT Token
        const token = jwt.sign(
          { user_id: newUser._id, email },
          process.env.VITE_JWT_TOKEN_KEY,
          {
            expiresIn: "2h",
          }
        );
        // Attach Token to user model that we found above
        user.token = token;

        return {
          id: user._id,
          ...user._doc,
        };
      } else {
        // if user doesn't exists return error
        throw new Error("Invalid Credentials");
      }
    },
  },
  Query: {
    user: (_, { ID }) => User.findById(ID),
  },
};
